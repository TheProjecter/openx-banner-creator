<?


class Plugins_ZetaPrints_oxZetaPrints_oxZetaPrints {

	function getName(){
		return "ZetaPrints";
	}


}